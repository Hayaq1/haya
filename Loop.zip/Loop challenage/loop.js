function odd(){
for( var i=1; i<=20; i++){

    if(i % 2 !=0){
        console.log(i);
    }
}
}

function three(){
    for( var i=100; i>=1; i--){
    
        if(i % 3 === 0){
            console.log(i);
        }
    }
    }

    function seq(){
        for( var i= 4; i>=-3; i-=1.5){
                console.log(i)
        }
        }  

        function sum(){
            var sum = 0;
            for( var i= 1; i<=100; i++){
                    console.log(i + "+");
                    sum += i;
                }
            console.log("the sum ="+ sum);
            }


            function pro(){
            var m =1;
            for(var i = 1; i<=12; i++){
                m *=i;
                console.log(i +"*");
            }
            console.log("the product it is ="+m);
            }
            